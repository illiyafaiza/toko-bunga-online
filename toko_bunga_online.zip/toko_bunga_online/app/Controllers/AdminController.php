<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\BungaModel;
use CodeIgniter\HTTP\ResponseInterface;

class AdminController extends BaseController 
{
    public function index() 
    {
        return view('admin/dashboard');
    }

    public function daftarBunga() 
    {
        $bungaModel = new BungaModel();
        $data['bungas'] = $bungaModel->findAll();
        return view('admin/daftar-bunga', $data);
    }

    public function daftarBungaTambah() 
    {
        return view('admin/daftar-bunga-tambah');
    }

    public function createBunga() 
    {
        $data = $this->request->getPost();
        $file = $this->request->getFile('gambar');

        if (!$file->hasMoved()) {
            $path = $file->store('images');
            $data['gambar'] = $path;
        }

        $bungaModel = new BungaModel();

        if ($bungaModel->insert($data, false)) {
            return redirect()->to('admin/daftar-bunga')->with('berhasil', 'Data bunga berhasil disimpan!');
        } else {
            return redirect()->to('admin/daftar-bunga')->with('gagal', 'Data bunga gagal disimpan!');
        }
    }

    public function daftarBungaEdit($id) 
    {
        $bungaModel = new BungasModel();
        $data['bunga'] = $bungaModel->find($id);
        
        if ($data['bunga']) {
            return view('admin/daftar-bunga-edit', $data);
        }
        return redirect()->to('admin/daftar-bunga')->with('gagal', 'Data bunga tidak ditemukan.');
    }

    public function updateBunga($id) 
    {
        $bungaModel = new BungasModel();
        $data = $this->request->getPost();
        
        // Handle image upload if new image is provided
        $file = $this->request->getFile('gambar');
        if ($file->isValid() && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['gambar'] = $path;
        }

        if ($bungaModel->update($id, $data)) {
            return redirect()->to('admin/daftar-bunga')->with('berhasil', 'Data bunga berhasil diupdate!');
        }
        return redirect()->to('admin/daftar-bunga')->with('gagal', 'Data bunga gagal diupdate!');
    }

    public function daftarBungaUpdate($id) 
    {
        $bungaModel = new BungasModel();
        $data = $this->request->getPost();
        
        // Handle image upload if new image is provided
        $file = $this->request->getFile('gambar');
        if ($file->isValid() && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['gambar'] = $path;
        }
        
        if ($bungaModel->update($id, $data)) {
            return redirect()->to('admin/daftar-bunga')->with('berhasil', 'Data bunga berhasil diupdate!');
        }
        return redirect()->to('admin/daftar-bunga')->with('gagal', 'Data bunga gagal diupdate!');
    }

    public function hapusBunga($id) 
    {
        $bungaModel = new BungaModel();
        $bunga = $bungaModel->find($id);

        if ($bunga) {
            $bungaModel->delete($id);
            return redirect()->to('/admin/daftar-bunga')->with('berhasil', 'Data bunga berhasil dihapus.');
        }
        return redirect()->to('/admin/daftar-bunga')->with('gagal', 'Data bunga tidak ditemukan.');
    }

    public function transaksi() 
    {
        return view('admin/transaksi');
    }

    public function transaksiUbahStatus() 
    {
        return view('admin/transaksi-ubah-status');
    }

    public function transaksiHapus() 
    {
        return view('admin/transaksi-hapus');
    }

    public function pelanggan() 
    {
        return view('admin/pelanggan');
    }

    public function pelangganHapus() 
    {
        return view('admin/pelanggan-hapus');
    }
}