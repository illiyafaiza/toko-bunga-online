<?= $this->extend('admin/template')?>

<?= $this->section('main')?>
<h2 class="mb-5">Tambah Bunga</h2>

<div class="w-50">
    <form action="<?= base_url('admin/daftar-bunga/tambah')?>" enctype="multipart/form-data" method="POST">
        <div class="mb-3">
            <label for="nama">Nama Bunga</label>
            <input type="text" class="form-control" name="nama" id="nama" required>
        </div>
        <div class="mb-3">
            <label for="jenis">Jenis Bunga</label>
            <input type="text" class="form-control" name="jenis" id="jenis" required>
        </div>
        <div class="mb-3">
            <label for="deskripsi">Deskripsi</label>
            <input type="text" class="form-control" name="deskripsi" id="deskripsi" required>
        </div>
        <div class="mb-3">
            <label for="waktu_mekar">waktu mekar</label>
            <input type="text" class="form-control" name="tahun_tanam" id="tahun_tanam" required>
        </div>
        <div class="mb-3">
            <label for="gambar">Gambar</label>
            <input type="file" name="gambar" id="gambar" class="form-control" required>
        </div>
        <div class="mb-3">
            <a href="<?= base_url('admin/daftar-bunga')?>" class="btn btn-secondary">Kembali</a>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
    </form>
</div>

<?= $this->endSection()?>