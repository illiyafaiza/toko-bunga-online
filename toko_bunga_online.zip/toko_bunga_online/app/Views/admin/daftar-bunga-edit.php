<?= $this->extend('admin/template') ?>  
<?= $this->section('main') ?>
    <div class="container">
        <h4>Edit Data Bunga</h4>
        <form action="<?= base_url('admin/daftar-bunga/update/' . $bunga['id']) ?>" method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label">Nama Bunga</label>
                <input type="text" class="form-control" name="nama" value="<?= $bunga['nama'] ?? '' ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Merek</label>
                <input type="text" class="form-control" name="merek" value="<?= $bunga['merek'] ?? '' ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Spesifikasi</label>
                <textarea class="form-control" name="spesifikasi" rows="3"><?= $bunga['spesifikasi'] ?? '' ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Tahun Rilis</label>
                <input type="number" class="form-control" name="tahun_rilis" value="<?= $bunga['tahun_rilis'] ?? '' ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Gambar</label>
                <input type="file" class="form-control" name="gambar">
                <?php if (!empty($bunga['gambar'])): ?>
                    <small class="text-muted">Gambar saat ini: <?= $bunga['gambar'] ?></small>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="form-label">Harga</label>
                <input type="number" class="form-control" name="harga" value="<?= $bunga['harga'] ?? '' ?>">
            </div>

            <button type="submit" class="btn btn-primary">Update</button>
            <a href="<?= base_url('admin/daftar-bunga') ?>" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
<?= $this->endSection() ?>
