<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/chart', 'Home::chart');
$routes->get('/checkout', 'Home::checkout');

$routes->post('/submit', 'Home::submit');

$routes->get('images/(:segment)', 'Home::image/$1');

$routes->group('admin', ['filter' => ['group:admin']], function($routes) {
    $routes->get('', 'AdminController::index');
    $routes->get('dashboard', 'AdminController::index');
    
    // Daftar Bunga routes
    $routes->get('daftar-bunga', 'AdminController::daftarBunga');
    $routes->get('daftar-bunga/tambah', 'AdminController::daftarBungaTambah');
    $routes->post('daftar-bunga/tambah', 'AdminController::createBunga');
    $routes->get('daftar-bunga/edit/(:num)', 'AdminController::daftarBungaEdit/$1');
    $routes->post('daftar-bunga/update/(:num)', 'AdminController::daftarBungaUpdate/$1'); // Ditambahkan route untuk update
    $routes->get('admin/daftar-bunga/edit/(:num)', 'Admin\DaftarBunga::edit/$1');
    $routes->post('admin/daftar-bunga/change', 'Admin\DaftarBunga::change');
    $routes->post('daftar-bunga/edit', 'AdminController::daftarBungaEdit');
    $routes->get('daftar-bunga/hapus', 'AdminController::daftarBungaHapus');
    
    $routes->get('daftar-bunga/hapus/(:num)', 'AdminController::hapusBunga/$1');
    $routes->get('admin/daftar-bunga/hapus/(:num)', 'AdminController::hapusBunga/$1');
    $routes->post('admin/daftar-bunga/hapus/(:num)', 'AdminController::hapusBunga/$1');
    
    // Transaksi routes
    $routes->get('transaksi', 'AdminController::transaksi');
    $routes->get('transaksi/ubah-status', 'AdminController::transaksiUbahStatus');
    $routes->get('transaksi/hapus', 'AdminController::transaksiHapus');
    
    // Pelanggan routes
    $routes->get('pelanggan', 'AdminController::pelanggan');
    $routes->get('pelanggan/hapus', 'AdminController::pelangganHapus');
});

service('auth')->routes($routes);